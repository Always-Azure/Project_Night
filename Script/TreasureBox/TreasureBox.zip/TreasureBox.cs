﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TreasureBox : MonoBehaviour
{

    public Item item;

    private List<Item> _itemList; // 상자에 들어있는 아이템 정보.
    private int _itemSize; // 아이템 갯수.
    private int _itemMaxSize;

    private GameObject Notice;
    private STATE_BOX state;
    private bool isAvailable;

    private Animator anim; // 애니메이션

    // Use this for initialization
    void Start()
    {
        _itemList = new List<Item>();
        _itemSize = 2;
        _itemMaxSize = 2;
        Item asdf = new Item();
        asdf.itemType = Item.ItemType.Battery;
        _itemList.Add(asdf);

        Notice = transform.Find("Canvas").gameObject;
        state = STATE_BOX.CLOSE;
        anim = GetComponent<Animator>();
        isAvailable = false;
    }

    // Update is called once per frame
    void Update()
    {
    }

    // Draw items in treasurebox.
    private void Draw(DRAWTYPE_BOX type, int insertIdx = 0)
    {
        // Clear Item Draw before redraw
        DisableAllObjects();

        // ReDraw Item
        switch (_itemSize)
        {
            case 1:
                {
                    Transform loc = transform.Find("Loc1").transform;
                    Transform pos = loc.transform.Find("Pos1").transform;
                    GameObject tmp = null;

                    // Handle by type.
                    // 아이템 종류를 받아서 해당 번호만 실행시키는 걸로 바꿔야 겠다.
                    switch (_itemList[0].itemType)
                    {
                        case Item.ItemType.Battery:
                            tmp = pos.GetChild(0).gameObject;
                            break;
                    }

                    tmp.SetActive(true);

                    if(type == DRAWTYPE_BOX.NORMAL)
                        tmp.GetComponent<Animator>().Play("Appear");
                    else
                        tmp.GetComponent<Animator>().Play("Rotate");
                }
                break;

            case 2:
                {
                    Transform loc = transform.Find("Loc2").transform;

                    for(int i = 1; i<=2; i++)
                    {
                        Transform pos = loc.transform.Find("Pos"+i).transform;
                        GameObject tmp = null;

                        // Handle by type.
                        switch (_itemList[(i-1)].itemType)
                        {
                            case Item.ItemType.Battery:
                                tmp = pos.GetChild(0).gameObject;
                                break;
                        }

                        tmp.SetActive(true);

                        if(type == DRAWTYPE_BOX.NORMAL)
                            tmp.GetComponent<Animator>().Play("Appear");
                        if(type == DRAWTYPE_BOX.INSERT && (i-1) == insertIdx)
                            tmp.GetComponent<Animator>().Play("Appear");
                        else
                            tmp.GetComponent<Animator>().Play("Rotate");
                    }
                }
                break;

            default:
                break;
        }
    }

    // 일단 insert와 remove를 따로 나누었지만, 왠만하면 draw 하나로 처리하고싶기에 수정 중이다.
    // Redraw items in treasurebox when item insert.
    public void insertDraw(int insertIdx)
    {
        // Clear Item Draw before redraw
        DisableAllObjects();

        // ReDraw Item
        switch (_itemSize)
        {
            case 1:
                {
                    Transform loc = transform.Find("Loc1").transform;
                    Transform pos = loc.transform.Find("Pos1").transform;
                    GameObject tmp = null;

                    // Handle by type.
                    // 아이템 종류를 받아서 해당 번호만 실행시키는 걸로 바꿔야 겠다.
                    switch (_itemList[0].itemType)
                    {
                        case Item.ItemType.Battery:
                            // enum을 형변환 할 때, 사용하는 데이터형이 뭐지...
                            tmp = pos.GetChild(0).gameObject;
                            break;
                    }

                    tmp.SetActive(true);
                    tmp.GetComponent<Animator>().Play("Appear");
                }
                break;

            case 2:
                {
                    Transform loc = transform.Find("Loc2").transform;

                    for (int i = 1; i <= 2; i++)
                    {
                        Transform pos = loc.transform.Find("Pos" + i).transform;
                        GameObject tmp = null;

                        // Handle by type.
                        switch (_itemList[(i - 1)].itemType)
                        {
                            case Item.ItemType.Battery:
                                tmp = pos.GetChild(0).gameObject;                                
                                break;
                        }

                        tmp.SetActive(true);

                        if ((i - 1) == insertIdx)
                            tmp.GetComponent<Animator>().Play("Appear");
                        else
                            tmp.GetComponent<Animator>().Play("Rotate");

                    }
                }
                break;

            default:
                break;
        }
    }

    // Redraw items in treasurebox when item remove.
    public void RemoveDraw()
    {
        // Clear Item Draw before redraw
        DisableAllObjects();

        // ReDraw Item
        switch (_itemSize)
        {
            case 1:
                {
                    Transform loc = transform.Find("Loc1").transform;
                    Transform pos = loc.transform.Find("Pos1").transform;
                    GameObject tmp = null;

                    // Handle by type.
                    // 아이템 종류를 받아서 해당 번호만 실행시키는 걸로 바꿔야 겠다.
                    switch (_itemList[0].itemType)
                    {
                        case Item.ItemType.Battery:
                            tmp = pos.GetChild(0).gameObject;
                            break;
                    }

                    tmp.SetActive(true);
                    tmp.GetComponent<Animator>().Play("Rotate");
                }
                break;

            case 2:
                {
                    Transform loc = transform.Find("Loc2").transform;

                    for (int i = 1; i <= 2; i++)
                    {
                        Transform pos = loc.transform.Find("Pos" + i).transform;
                        GameObject tmp = null;

                        // Handle by type.
                        switch (_itemList[(i - 1)].itemType)
                        {
                            case Item.ItemType.Battery:
                                tmp = pos.GetChild(0).gameObject;
                                break;
                        }

                        tmp.SetActive(true);
                        tmp.GetComponent<Animator>().Play("Rotate");
                    }
                }
                break;

            default:
                break;
        }
    }

    // 상자에 들어있는 모든 object들을 비활성화 시키기.
    private void DisableAllObjects()
    {
        int idx = 1;

        // 상자에 담길 수 있는 만큼 돌리면 된다.
        for (; idx <= _itemMaxSize; idx++)
        {
            Transform loc = transform.Find("Loc" + idx).transform;

            for (int i = 1; i <= idx; i++)
            {
                Transform pos = loc.transform.Find("Pos" + i).transform;

                // item 종류 수 만큼 돌리면 된다.
                for (int j = 0; j < 1; j++)
                {
                    Debug.Log("아이템 disable");
                    pos.GetChild(j).gameObject.SetActive(false);
                }
            }
        }
    }

    /*
     * Insert item.
     * true - success insert
     * false - fail insert
     */
    public bool InsertItem(Item item, int idx)
    {
        if (_itemSize > _itemMaxSize)
            return false;

        _itemList.Insert(idx, item);

        insertDraw(idx);

        return true;
    }

    /*
     * remove item.
     * true - success remove
     * false - fail remove
     */
    public bool RemoveItem(Item item)
    {
        if (_itemSize == 0)
            return false;

        _itemList.Remove(item);

        RemoveDraw();

        return true;
    }

    /*
     * Return inner information of treasurebox.
     * Return itemList.
     */
    public List<Item> GetBoxInfo()
    {
        return _itemList;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("박스 진입");
            if (state == STATE_BOX.OPEN)
                return;

            Notice.SetActive(true);
            isAvailable = true;
            
            // anim.CrossFade("BoxOpen", 1); // 애니메이션을 부드럽게 이어주는 것.
        }
    }

    /*
     * 음... TriggerStay로 해주는게 좋을지, Flag를 걸어서 Update에 해주는게 좋을지 모르겠다.
     */
    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            if (Input.GetKeyDown(KeyCode.F) && state == STATE_BOX.CLOSE)
            {
                state = STATE_BOX.OPEN;
                Notice.SetActive(false);
                anim.Play("BoxOpen");

                Draw(DRAWTYPE_BOX.NORMAL);

                //item.OnBoxOpen();
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("박스 탈출");

            state = STATE_BOX.CLOSE;

            Notice.SetActive(false);
            isAvailable = false;

            DisableAllObjects();

            anim.Play("Idle");
        }
    }
}
